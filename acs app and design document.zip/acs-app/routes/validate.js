// Small helpers shared by the routes, so every form is checked the same way.

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function cleanText(value) {
    return typeof value === 'string' ? value.trim() : '';
}

function isValidEmail(value) {
    return EMAIL_PATTERN.test(value) && value.length <= 255;
}

function isValidUrl(value) {
    if (value.length > 255) return false;
    try {
        const url = new URL(value);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch {
        return false;
    }
}

// Turns "12" into 12, and anything that isn't a positive whole number into null
function toId(value) {
    const id = Number(value);
    return Number.isInteger(id) && id > 0 ? id : null;
}

module.exports = { cleanText, isValidEmail, isValidUrl, toId };
