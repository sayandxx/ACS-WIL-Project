const jwt = require('jsonwebtoken');

// The secret used to sign login tokens. Set JWT_SECRET in your .env file.
// In development we fall back to a fixed value so the app still runs, but warn about it.
function getSecret() {
    if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
    if (process.env.NODE_ENV === 'production') {
        throw new Error('JWT_SECRET must be set in production.');
    }
    if (!getSecret.warned) {
        console.warn('JWT_SECRET is not set in .env, using an insecure development secret.');
        getSecret.warned = true;
    }
    return 'dev-only-secret-change-me';
}

// Creates a login token that lasts 8 hours
function createToken(user) {
    return jwt.sign({ id: user.id, account_type: user.account_type }, getSecret(), { expiresIn: '8h' });
}

// Reads "Authorization: Bearer <token>" and returns the user inside it, or null
function readUser(req) {
    const header = req.headers.authorization || '';
    const [scheme, token] = header.split(' ');
    if (scheme !== 'Bearer' || !token) return null;
    try {
        return jwt.verify(token, getSecret());
    } catch {
        return null;
    }
}

// Blocks the request unless the user is logged in
function requireAuth(req, res, next) {
    const user = readUser(req);
    if (!user) {
        return res.status(401).json({ message: 'Please log in to continue.' });
    }
    req.user = user;
    next();
}

// Lets the request through either way, but attaches the user if logged in
function optionalAuth(req, res, next) {
    req.user = readUser(req);
    next();
}

// Blocks the request unless the logged-in user has one of the given account types
function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.account_type)) {
            return res.status(403).json({ message: 'Your account type cannot do this.' });
        }
        next();
    };
}

module.exports = { createToken, requireAuth, optionalAuth, requireRole };
